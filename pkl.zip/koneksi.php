<?php
 
	$host 			= "localhost"; 	// definisi variabel host.
	$username		= "root"; 
	$password 		= ""; 			// karna saya menggunakan XAMPP secara default pass kosong!!!
	$db 			= "pkl"; 		//definisi variable db_name (nama_database)
	//phpinfo();
	$konek = mysqli_connect($host,$username,$password,$db);//
 
?>